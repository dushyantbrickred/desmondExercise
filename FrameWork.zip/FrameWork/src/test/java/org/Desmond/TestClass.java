package org.Desmond;

import org.Desmond.base.BaseTest;
import org.Desmond.pages.*;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TestClass extends BaseTest {

    @Test
    public void sauceDemoTest() throws InterruptedException {


        HomePage homePage = new HomePage(driver);
        homePage.load();
        ProductsPage productsPage = homePage.login("standard_user","secret_sauce");
        Thread.sleep(5000);
        Assert.assertEquals(productsPage.productsPageTitle().toLowerCase(),"products");
        YourCartPage yourCartPage = productsPage.addToCartForBackpackBtn().
                                                 aclickShoppingCartBtn();
        Thread.sleep(5000);

        Assert.assertEquals(yourCartPage.yourCartPageTitle().toLowerCase(),"your cart");
        CheckoutPage checkoutPage = yourCartPage.productName("Sauce Labs Backpack")
                                                 .clickCheckouttBtn();

        Assert.assertEquals(checkoutPage.checkoutPageTitle().toLowerCase(),"CHECKOUT: YOUR INFORMATION".toLowerCase());
        CheckoutOverViewPage checkoutOverViewPage = checkoutPage.checkout("desmond","Moroane","1000").
                                                    continueBtn();

        Thread.sleep(2000);

        Assert.assertEquals(checkoutOverViewPage.checkoutOverViewPageTitle().toLowerCase(),"CHECKOUT: OVERVIEW".toLowerCase());
        checkoutOverViewPage.
                finishBtn();








    }
}
