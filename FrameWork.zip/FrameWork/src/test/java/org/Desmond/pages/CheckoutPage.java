package org.Desmond.pages;

import org.Desmond.base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CheckoutPage  extends BasePage {

    private final By checkoutPageTitle = By.xpath("//*[@id=\"header_container\"]/div[2]/span");

    private final By firstName = By.xpath("//*[@id=\"first-name\"]");

    private final By lastName = By.xpath("//*[@id=\"last-name\"]");

    private final By postCode = By.xpath("//*[@id=\"postal-code\"]");

    private final By continueBtn = By.xpath("//*[@id=\"continue\"]");


    public String checkoutPageTitle() {

        return driver.findElement(checkoutPageTitle).getText();
    }

    public CheckoutOverViewPage continueBtn() {
        driver.findElement(continueBtn).click();
        return new CheckoutOverViewPage(driver);
    }

    public CheckoutPage checkout(String fName, String lName, String pCode){
        driver.findElement(firstName).sendKeys(fName);
        driver.findElement(lastName).sendKeys(lName);
        driver.findElement(postCode).sendKeys(pCode);
        return this;
    }
    public CheckoutPage(WebDriver driver) {
        super(driver);
    }
}
