package org.Desmond.objects;

import org.Desmond.base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class YourCartPage extends BasePage {

    private final By yourCartPageTitle = By.xpath("//*[@id=\"header_container\"]/div[2]/span");

    private final By productName = By.xpath("//div[@class='inventory_item_name']");

    private final By clickCheckoutBtn = By.xpath("//*[@id=\"checkout\"]");
    public YourCartPage(WebDriver driver) {
        super(driver);
    }

    public String yourCartPageTitle() {

        return driver.findElement(yourCartPageTitle).getText();
    }

    public void productName(String product) {
        List<WebElement> cartList = driver.findElements(productName);
        for (WebElement cartProducts: cartList) {
            if(cartProducts.getText().equalsIgnoreCase(product)){
                break;
            }
        }
    }


    public CheckoutPage clickCheckouttBtn() {
        driver.findElement(clickCheckoutBtn).click();
        return new CheckoutPage(driver);
    }

    @Override
    protected void finalize() throws Throwable {


    }
}
