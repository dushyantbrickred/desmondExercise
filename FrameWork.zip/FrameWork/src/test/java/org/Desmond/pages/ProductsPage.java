package org.Desmond.pages;

import org.Desmond.base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProductsPage extends BasePage {

    private final By productsPageTitle = By.xpath("//*[@id=\"header_container\"]/div[2]/span");

    private final By addToCartForBackpackBtn = By.xpath("//*[@id=\"add-to-cart-sauce-labs-backpack\"]");

    private final By clickShoppingCartBtn = By.xpath("//*[@id=\"shopping_cart_container\"]/a");

    public ProductsPage(WebDriver driver) {
        super(driver);
    }

    public String productsPageTitle() {

        return driver.findElement(productsPageTitle).getText();
    }

    public ProductsPage addToCartForBackpackBtn() {
        driver.findElement(addToCartForBackpackBtn).click();
        return this;
    }

    public YourCartPage aclickShoppingCartBtn() {
        driver.findElement(clickShoppingCartBtn).click();
        return new YourCartPage(driver);
    }

    //Sauce Labs Backpack

    //standard_user

    //secret_sauce

}
