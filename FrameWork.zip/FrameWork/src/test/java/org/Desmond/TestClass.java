package org.Desmond;

import org.Desmond.base.BaseTest;
import org.testng.annotations.Test;

public class TestClass extends BaseTest {

    @Test
    public void sauceDemoTest() {



    }
}
