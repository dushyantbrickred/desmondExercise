package org.Desmond.objects;

import org.Desmond.base.BasePage;
import org.openqa.selenium.WebDriver;

public class CheckoutPage  extends BasePage {
    public CheckoutPage(WebDriver driver) {
        super(driver);
    }
}
