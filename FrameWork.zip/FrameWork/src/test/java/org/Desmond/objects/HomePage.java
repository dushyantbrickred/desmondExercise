package org.Desmond.objects;

import org.Desmond.base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage extends BasePage {

    private final By userName = By.xpath("//*[@id=\"user-name\"]");

    private final By password = By.xpath("//*[@id=\"password\"]");

    private final By loginBtn = By.xpath("//*[@id=\"login-button\"]");

    public HomePage(WebDriver driver) {
        super(driver);
    }

    public HomePage load (){
        navigateToUrl("/");
        return this;
    }

    public ProductsPage login(String user, String pwd){
        driver.findElement(userName).sendKeys(user);
        driver.findElement(password).sendKeys(pwd);
        driver.findElement(loginBtn).click();
        return  new ProductsPage(driver);
    }
}
