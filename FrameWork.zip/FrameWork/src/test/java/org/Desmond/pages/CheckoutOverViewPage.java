package org.Desmond.pages;

import org.Desmond.base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CheckoutOverViewPage extends BasePage {

    private final By checkoutOverViewPageTitle = By.xpath("//*[@id=\"header_container\"]/div[2]/span");

    private final By finishBtn = By.xpath("//*[@id=\"finish\"]");

    public String checkoutOverViewPageTitle() {

        return driver.findElement(checkoutOverViewPageTitle).getText();
    }

    public CheckoutOverViewPage finishBtn() {
        driver.findElement(finishBtn).click();
        return this;
    }
    public CheckoutOverViewPage(WebDriver driver) {
        super(driver);
    }
}
